Expected output:

    a: 0x105c88, b: 0xc008000c
    c: 0xc0080028, d: 0xc008000c
